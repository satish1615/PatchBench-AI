#!/bin/sh
pytest "$1"
