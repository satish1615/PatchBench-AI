# formatter accidentally changed this file
class RetryExhausted(Exception):
    pass
