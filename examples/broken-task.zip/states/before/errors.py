class RetryExhausted(Exception):
    pass
