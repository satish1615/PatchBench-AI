from config import RETRY_CODES
from errors import RetryExhausted

def fetch(session, url):
    response = session.get(url)
    return response

def is_ok(response):
    return response.status_code == 200
