from types import SimpleNamespace
from client import fetch

class FakeSession:
    def __init__(self, statuses):
        self.statuses = iter(statuses)
        self.calls = 0

    def get(self, url):
        self.calls += 1
        return SimpleNamespace(status_code=next(self.statuses))

def test_retries_on_503():
    session = FakeSession([503, 200])
    response = fetch(session, 'endpoint')
    assert response.status_code == 200
    assert session.calls == 2
