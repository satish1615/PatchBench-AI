from types import SimpleNamespace
from client import fetch

class FakeSession:
    def __init__(self, statuses):
        self.statuses = iter(statuses)
        self.calls = 0

    def get(self, url):
        self.calls += 1
        return SimpleNamespace(status_code=next(self.statuses))

def test_success():
    session = FakeSession([200])
    assert fetch(session, 'endpoint').status_code == 200
    assert session.calls == 1

def test_unauthorized():
    session = FakeSession([401])
    assert fetch(session, 'endpoint').status_code == 401
    assert session.calls == 1
