#!/bin/sh
set -eu
STATE="${STATE:-after}"
case "$STATE" in before|after) ;; *) echo 'STATE must be before or after' >&2; exit 2 ;; esac
export PYTHONPATH="$(pwd)/states/$STATE${PYTHONPATH:+:$PYTHONPATH}"
if [ "$#" -eq 0 ]; then
    python -m pytest -q tests/fail2pass tests/pass2pass
else
    # Individual test IDs are comma separated. Shell splitting is deliberate.
    old_IFS="$IFS"
    IFS=','
    set -- $1
    IFS="$old_IFS"
    python -m pytest -q "$@"
fi
